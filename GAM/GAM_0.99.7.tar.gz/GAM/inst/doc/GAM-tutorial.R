## ----eval=TRUE, echo=FALSE, message=FALSE--------------------------------
require(knitr)
opts_chunk$set(error=TRUE, cache=TRUE, dev="svg")

## ----message=FALSE-------------------------------------------------------
library("GAM")
library("GAM.db")
library("igraph")
data("examplesGAM")

## ------------------------------------------------------------------------
library(RCurl)
gene.de.M0.M1 <- read.csv(text=getURL("http://artyomovlab.wustl.edu/publications/supp_materials/GAM/Ctrl.vs.MandLPSandIFNg.gene.de.tsv"), sep="\t")
met.de.M0.M1 <- read.csv(text=getURL("http://artyomovlab.wustl.edu/publications/supp_materials/GAM/Ctrl.vs.MandLPSandIFNg.met.de.tsv"), sep="\t")

## ------------------------------------------------------------------------
library("GAM.networks")
data("kegg.mouse.network")

## ----cache=TRUE, error=FALSE, message=FALSE, fig.width=4, fig.height=4----
es.re <- makeExperimentSet(network=kegg.mouse.network,
                           met.de=met.de.M0.M1,
                           gene.de=gene.de.M0.M1,
                           reactions.as.edges=T)

## ------------------------------------------------------------------------
head(es.re$gene.de)
head(es.re$met.de)
head(es.re$rxn.de)
es.re$subnet

## ------------------------------------------------------------------------
solver <- heinz2.solver("/usr/local/lib/heinz2/heinz", timeLimit=30)
print(solver)

## ------------------------------------------------------------------------
met.fdr <- 3e-5
rxn.fdr <- 3e-5
absent.met.score <- -20

## ----chache=TRUE, error=FALSE, eval=FALSE--------------------------------
#  module.re <- findModule(es.re,
#                          met.fdr=met.fdr,
#                          rxn.fdr=rxn.fdr,
#                          absent.met.score=absent.met.score,
#                          solver=solver)

## ----chache=TRUE, error=FALSE--------------------------------------------
module.re

## ----fig.width=8,fig.height=8,error=FALSE,message=FALSE------------------
plotNetwork(module.re)

## ----error=FALSE---------------------------------------------------------
saveModule(module.re,
           paste0("module.M0.M1.re", 
                  ".mf=", met.fdr,
                  ".rf=", rxn.fdr,
                  ".ms=", absent.met.score),
           types=c("pdf", "XGMML")
)

## ----echo=FALSE----------------------------------------------------------
system.file("GAM_VizMap.xml", package="GAM")

## ----chache=TRUE, error=FALSE, message=FALSE-----------------------------
es.rn <- makeExperimentSet(network=kegg.mouse.network,
                           met.de=met.de.M0.M1,
                           gene.de=gene.de.M0.M1,
                           reactions.as.edges=F,
                           plot=F)
es.rn$subnet

## ------------------------------------------------------------------------
met.fdr=c(5e-6)
rxn.fdr=c(5e-6)

## ----eval=FALSE----------------------------------------------------------
#  module.rn <- findModule(es.rn,
#                          met.fdr=met.fdr,
#                          rxn.fdr=rxn.fdr,
#                          solver=solver)

## ------------------------------------------------------------------------
module.rn

## ----fig.width=8, fig.height=8, error=FALSE,message=FALSE----------------
plotNetwork(module.rn)

## ------------------------------------------------------------------------
library("GAM.db")
data(kegg.db)
names(kegg.db)

## ------------------------------------------------------------------------
head(kegg.db$rxn2enz)
head(kegg.db$enz2gene)

## ------------------------------------------------------------------------
head(kegg.db$net)

## ------------------------------------------------------------------------
head(kegg.db$rxn2name)
head(kegg.db$met2name)

## ------------------------------------------------------------------------
head(kegg.db$mets2mask)
head(kegg.db$rxns2mask)

## ------------------------------------------------------------------------
head(kegg.db$mets2collapse)

## ----cache=TRUE----------------------------------------------------------
kegg.mouse.network <- makeKeggNetwork(kegg.db, "MMU")

## ------------------------------------------------------------------------
head(kegg.mouse.network$graph.raw)

## ----cache=TRUE----------------------------------------------------------
kegg.db$net <- rbind(kegg.db$net, c("C00417", "RXIRG1", "C00490", "RPXIRG1", "main"))
kegg.db$rxn2enz <- rbind(kegg.db$rxn2enz, c("RXIRG1", "Irg1"))
kegg.db$enz2gene <- rbind(kegg.db$enz2gene, c("Irg1", "16365", "MMU"))
kegg.mouse.network <- makeKeggNetwork(kegg.db, "MMU")

## ------------------------------------------------------------------------
module.re <- addTransEdges(module.re, es.re)

## ------------------------------------------------------------------------
module.rn <- addMetabolitesForReactions(module.rn, es.rn)

## ------------------------------------------------------------------------
module.rn <- addInterconnections(module.rn, es.rn)

## ------------------------------------------------------------------------
module.rn <- addNormLogFC(module.rn)

## ------------------------------------------------------------------------
module.rn <- removeHangingNodes(module.rn)

## ------------------------------------------------------------------------
module.rn <- simplifyReactionNodes(module.rn, es.rn)

## ------------------------------------------------------------------------
module.rn <- expandReactionNodeAttributesToEdges(module.rn)

