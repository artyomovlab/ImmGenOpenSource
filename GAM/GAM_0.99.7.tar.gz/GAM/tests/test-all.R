library(testthat)

library(GAM)
test_package("GAM")

#test_check("GAM")
